CLEAN TAKE — FOLLOW ALONG WITH THE VIDEO

Included:
- morning-routine.mp4: Wesley's original short practice recording, including a false start and pauses.
- prompts.txt: cleaned-up prompts matching the recorded tutorial's main steps, plus explicit safety notes.

Create your own Lovable project, use the initial prompt in Plan mode, review the plan, and build. Connect your own restricted ElevenLabs transcription key through the secure connector. Upload morning-routine.mp4, transcribe it, request cut suggestions, review them, preview the edited result, and export a new MP4. Keep the original recording.

For the MCP step, publish your own app, use its own Agent Integrations connection details, and approve access in your chosen assistant. Do not use Wesley's private project IDs or credentials. Use the current instructions for your assistant; the precise interface can change.

This is a small tutorial editor for short clips, not a substitute for a full editing suite. Results, credit costs and generated layouts can differ. No API keys, app source archive or private project details are included here.
